window.downloadFileFromText = (filename, content, contentType) => {
    const blob = new Blob([content], { type: contentType || "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    anchor.click();
    URL.revokeObjectURL(url);
};